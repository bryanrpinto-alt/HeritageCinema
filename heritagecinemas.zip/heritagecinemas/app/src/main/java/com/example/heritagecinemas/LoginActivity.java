package com.example.heritagecinemas;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

/**
 * Tela 1 — Login. Protótipo navegável: valida e-mail/senha (simulação de erro)
 * e leva para a Home.
 */
public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        TextInputLayout layoutEmail = findViewById(R.id.layoutEmail);
        TextInputLayout layoutSenha = findViewById(R.id.layoutSenha);
        TextInputEditText editEmail = findViewById(R.id.editEmail);
        TextInputEditText editSenha = findViewById(R.id.editSenha);
        TextView textErro = findViewById(R.id.textErroLogin);
        TextView btnEntrar = findViewById(R.id.btnEntrar);
        TextView textCriarConta = findViewById(R.id.textCriarConta);

        btnEntrar.setOnClickListener(v -> {
            String email = campo(editEmail);
            String senha = campo(editSenha);

            layoutEmail.setError(null);
            layoutSenha.setError(null);
            textErro.setVisibility(TextView.GONE);

            if (email.isEmpty()) {
                layoutEmail.setError("Informe seu e-mail");
                return;
            }
            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                layoutEmail.setError("Formato de e-mail inválido");
                return;
            }
            if (senha.isEmpty()) {
                layoutSenha.setError("Informe sua senha");
                return;
            }
            if (senha.length() < 4) {
                // Simulação de situação de erro: credenciais rejeitadas
                textErro.setText(R.string.erro_credenciais);
                textErro.setVisibility(TextView.VISIBLE);
                return;
            }

            startActivity(new Intent(this, HomeActivity.class));
            finish();
        });

        textCriarConta.setOnClickListener(v -> {
            textErro.setText(R.string.aviso_criar_conta);
            textErro.setVisibility(TextView.VISIBLE);
        });
    }

    private String campo(TextInputEditText edit) {
        return edit.getText() == null ? "" : edit.getText().toString().trim();
    }
}
