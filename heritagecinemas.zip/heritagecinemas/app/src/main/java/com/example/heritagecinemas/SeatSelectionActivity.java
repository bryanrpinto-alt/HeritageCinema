package com.example.heritagecinemas;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Tela 4 — Escolher sessão e assentos. Grade de assentos interativa e uso de
 * Bluetooth (recurso de hardware) para conectar fones/audiodescrição da sessão,
 * com pedido de permissão e simulação de negação.
 */
public class SeatSelectionActivity extends AppCompatActivity {

    private static final int COLUNAS = 8;
    private static final int FILEIRAS = 6;
    private static final String FILEIRAS_LABEL = "ABCDEF";

    private final List<String> selecionados = new ArrayList<>();
    private TextView textAssentosSelecionados;
    private TextView textStatusBluetooth;
    private String horario = "14:20";

    private ActivityResultLauncher<String> bluetoothPermissionLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seat_selection);

        String filmeExtra = getIntent().getStringExtra("FILME");
        final String filme = filmeExtra != null ? filmeExtra : "Verity";
        ((TextView) findViewById(R.id.textFilmeSessao)).setText(filme);

        textAssentosSelecionados = findViewById(R.id.textAssentosSelecionados);
        textStatusBluetooth = findViewById(R.id.textStatusBluetooth);

        findViewById(R.id.btnVoltar).setOnClickListener(v -> finish());

        configurarHorarios();
        montarGradeAssentos();
        configurarBluetooth();

        findViewById(R.id.btnContinuar).setOnClickListener(v -> {
            if (selecionados.isEmpty()) {
                // Simulação de situação de erro: tentar continuar sem assento
                Toast.makeText(this, R.string.erro_sem_assento,
                        Toast.LENGTH_LONG).show();
                return;
            }
            Intent intent = new Intent(this, TicketConfirmationActivity.class);
            intent.putExtra("FILME", filme);
            intent.putExtra("ASSENTOS", String.join(", ", selecionados));
            intent.putExtra("HORARIO", horario);
            startActivity(intent);
        });
    }

    private void configurarHorarios() {
        Button btn1 = findViewById(R.id.btnHora1);
        Button btn2 = findViewById(R.id.btnHora2);
        Button btn3 = findViewById(R.id.btnHora3);
        Button[] botoes = {btn1, btn2, btn3};
        for (Button b : botoes) {
            b.setOnClickListener(v -> {
                horario = b.getText().toString();
                for (Button outro : botoes) {
                    boolean ativo = outro == b;
                    outro.setBackgroundResource(
                            ativo ? R.drawable.bg_button_gold : R.drawable.bg_button_outline);
                    outro.setTextColor(ativo
                            ? getColor(R.color.black) : getColor(R.color.gold));
                }
            });
        }
    }

    private void montarGradeAssentos() {
        GridLayout grade = findViewById(R.id.gradeAssentos);
        grade.setColumnCount(COLUNAS + 1);

        // Determinístico: os mesmos assentos "ocupados" toda vez
        Random random = new Random(42);
        boolean[][] ocupados = new boolean[FILEIRAS][COLUNAS];
        for (int i = 0; i < FILEIRAS; i++) {
            for (int j = 0; j < COLUNAS; j++) {
                ocupados[i][j] = random.nextInt(100) < 25;
            }
        }

        for (int i = 0; i < FILEIRAS; i++) {
            // Rótulo da fileira (A, B, C...)
            TextView rotulo = new TextView(this);
            rotulo.setText(String.valueOf(FILEIRAS_LABEL.charAt(i)));
            rotulo.setTextColor(getColor(R.color.text_muted));
            rotulo.setTextSize(11f);
            rotulo.setGravity(Gravity.CENTER);
            grade.addView(rotulo, paramsCelula());

            for (int j = 0; j < COLUNAS; j++) {
                String idAssento = FILEIRAS_LABEL.charAt(i) + String.valueOf(j + 1);
                ImageView assento = new ImageView(this);
                assento.setContentDescription(idAssento);
                boolean ocupado = ocupados[i][j];
                assento.setImageResource(ocupado
                        ? R.drawable.seat_taken : R.drawable.seat_available);
                assento.setPadding(6, 6, 6, 6);
                if (!ocupado) {
                    assento.setOnClickListener(v -> alternarAssento(assento, idAssento));
                }
                grade.addView(assento, paramsCelula());
            }
        }
    }

    private GridLayout.LayoutParams paramsCelula() {
        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.width = 0;
        params.height = GridLayout.LayoutParams.WRAP_CONTENT;
        params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        params.setMargins(4, 4, 4, 4);
        return params;
    }

    private void alternarAssento(ImageView assento, String idAssento) {
        if (selecionados.contains(idAssento)) {
            selecionados.remove(idAssento);
            assento.setImageResource(R.drawable.seat_available);
        } else {
            selecionados.add(idAssento);
            assento.setImageResource(R.drawable.seat_selected);
        }
        textAssentosSelecionados.setText(selecionados.isEmpty()
                ? getString(R.string.assentos_selecionados_vazio)
                : getString(R.string.assentos_selecionados,
                        String.join(", ", selecionados)));
    }

    // Segundo recurso de hardware: Bluetooth (fones/audiodescrição da sessão)
    private void configurarBluetooth() {
        // Ouvinte que recebe a resposta do usuário ao popup de permissão
        bluetoothPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                concedida -> {
                    if (concedida) {
                        conectarFonesBluetooth();
                    } else {
                        // Simulação de negação de permissão
                        textStatusBluetooth.setText(R.string.bluetooth_negado);
                    }
                });

        findViewById(R.id.btnBluetooth).setOnClickListener(v -> {
            // No Android 12+ (API 31) conectar a fones exige permissão em tempo real
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                    && ContextCompat.checkSelfPermission(this,
                    Manifest.permission.BLUETOOTH_CONNECT)
                    != PackageManager.PERMISSION_GRANTED) {
                bluetoothPermissionLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT);
            } else {
                conectarFonesBluetooth();
            }
        });
    }

    private void conectarFonesBluetooth() {
        BluetoothManager manager = getSystemService(BluetoothManager.class);
        BluetoothAdapter adapter = manager != null ? manager.getAdapter() : null;
        if (adapter == null) {
            textStatusBluetooth.setText(R.string.bluetooth_indisponivel);
            return;
        }
        if (!adapter.isEnabled()) {
            // Simulação de erro: Bluetooth desligado
            textStatusBluetooth.setText(R.string.bluetooth_desligado);
            return;
        }
        String nome = adapter.getName();
        textStatusBluetooth.setText(getString(
                R.string.bluetooth_conectado, nome != null ? nome : "aparelho"));
    }
}
