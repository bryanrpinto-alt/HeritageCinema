package com.example.heritagecinemas;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Tela 3 — Detalhes do filme. Exibe as informações do filme escolhido na Home
 * e leva para a escolha de sessão/assentos.
 */
public class MovieDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_details);

        String filmeExtra = getIntent().getStringExtra("FILME");
        final String filme = filmeExtra != null ? filmeExtra : "Verity";

        TextView textTitulo = findViewById(R.id.textTituloFilme);
        TextView textPoster = findViewById(R.id.textPosterTitulo);
        TextView textInfo = findViewById(R.id.textInfoFilme);
        TextView textSinopse = findViewById(R.id.textSinopse);
        TextView textDirecao = findViewById(R.id.textDirecao);
        TextView textElenco = findViewById(R.id.textElenco);
        FrameLayout poster = findViewById(R.id.posterFilme);
        ImageView imagePoster = findViewById(R.id.imagePoster);

        textTitulo.setText(filme);
        textPoster.setText(filme.toUpperCase());

        if (filme.equals("A Odisseia")) {
            poster.setBackgroundResource(R.drawable.poster_odisseia);
            imagePoster.setVisibility(View.GONE);
            textInfo.setText(R.string.odisseia_details_info);
            textSinopse.setText(R.string.odisseia_details_synopsis);
            textDirecao.setText(R.string.odisseia_details_direction);
            textElenco.setText(R.string.odisseia_details_cast);
        }

        findViewById(R.id.btnVoltar).setOnClickListener(v -> finish());

        findViewById(R.id.btnEscolherSessao).setOnClickListener(v -> {
            Intent intent = new Intent(this, SeatSelectionActivity.class);
            intent.putExtra("FILME", filme);
            startActivity(intent);
        });
    }
}
