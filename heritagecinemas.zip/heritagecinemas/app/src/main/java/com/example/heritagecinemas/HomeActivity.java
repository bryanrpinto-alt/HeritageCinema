package com.example.heritagecinemas;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.os.Looper;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;

import java.util.Locale;
import java.util.Map;

/**
 * Tela 2 — Home. Lista os filmes em cartaz e usa GPS (recurso de hardware)
 * para localizar o usuário e calcular a distância até o cinema mais próximo.
 * GPS implementado conforme o Bloco 1 do tutorial (FusedLocationProviderClient).
 */
public class HomeActivity extends AppCompatActivity {

    // Local fixo do "Shopping Aurora" (protótipo) para calcular a distância
    private static final double CINEMA_LAT = -23.5505;
    private static final double CINEMA_LONG = -46.6333;

    private TextView textCinemaProximo;
    private FusedLocationProviderClient fusedLocationClient;
    private ActivityResultLauncher<String[]> localizacaoLauncher;
    private LocationCallback locationCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        textCinemaProximo = findViewById(R.id.textCinemaProximo);
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        // Ouvinte que recebe a localização assim que ela é encontrada
        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult == null) return;
                for (Location location : locationResult.getLocations()) {
                    float[] distancia = new float[1];
                    Location.distanceBetween(
                            location.getLatitude(), location.getLongitude(),
                            CINEMA_LAT, CINEMA_LONG, distancia);
                    double km = distancia[0] / 1000.0;
                    textCinemaProximo.setText(String.format(
                            Locale.getDefault(),
                            "Shopping Aurora - %.1f km (GPS: %.4f, %.4f)",
                            km, location.getLatitude(), location.getLongitude()));
                }
                // Para de escutar novas atualizações após receber a primeira
                fusedLocationClient.removeLocationUpdates(locationCallback);
            }
        };

        // Ouvinte que recebe a resposta do usuário ao popup de permissão
        localizacaoLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestMultiplePermissions(),
                (Map<String, Boolean> resultado) -> {
                    Boolean fineConcedida =
                            resultado.get(Manifest.permission.ACCESS_FINE_LOCATION);
                    Boolean coarseConcedida =
                            resultado.get(Manifest.permission.ACCESS_COARSE_LOCATION);
                    // Aceita se qualquer uma das duas permissões foi concedida
                    if (Boolean.TRUE.equals(fineConcedida)
                            || Boolean.TRUE.equals(coarseConcedida)) {
                        solicitarAtualizacaoLocalizacao();
                    } else {
                        // Simulação de negação de permissão
                        textCinemaProximo.setText(R.string.erro_permissao_localizacao);
                    }
                }
        );

        Button botaoLocalizacao = findViewById(R.id.btnPegarLocalizacao);
        botaoLocalizacao.setOnClickListener(view -> {
            // Verifica se a permissão já foi concedida
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED) {
                solicitarAtualizacaoLocalizacao();
            } else {
                // Ainda não tem permissão: dispara o popup de solicitação
                localizacaoLauncher.launch(new String[]{
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                });
            }
        });

        // Navegação para os detalhes dos filmes
        findViewById(R.id.btnSaibaMais).setOnClickListener(v ->
                abrirDetalhes("Verity"));
        findViewById(R.id.cardVerity).setOnClickListener(v ->
                abrirDetalhes("Verity"));
        findViewById(R.id.cardOdisseia).setOnClickListener(v ->
                abrirDetalhes("A Odisseia"));
    }

    private void abrirDetalhes(String filme) {
        Intent intent = new Intent(this, MovieDetailsActivity.class);
        intent.putExtra("FILME", filme);
        startActivity(intent);
    }

    // Solicita uma única atualização de localização, com alta precisão
    private void solicitarAtualizacaoLocalizacao() {
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        textCinemaProximo.setText(R.string.cinema_locating);
        // Alta precisão, buscando a cada 2 segundos
        LocationRequest locationRequest = new LocationRequest.Builder(
                Priority.PRIORITY_HIGH_ACCURACY, 2000)
                .setMaxUpdates(1) // recebe só uma atualização e para
                .build();
        fusedLocationClient.requestLocationUpdates(
                locationRequest,
                locationCallback,
                Looper.getMainLooper()
        );
    }
}
