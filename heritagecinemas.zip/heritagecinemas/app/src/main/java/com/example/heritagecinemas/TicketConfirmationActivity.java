package com.example.heritagecinemas;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

/**
 * Tela 5 — Ingresso confirmado. Mostra o resumo da compra (filme, sessão,
 * assentos) e um código de ingresso com QR Code simulado.
 */
public class TicketConfirmationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ticket_confirmation);

        String filme = getIntent().getStringExtra("FILME");
        String assentos = getIntent().getStringExtra("ASSENTOS");
        String horario = getIntent().getStringExtra("HORARIO");

        if (filme == null) filme = "Verity";
        if (assentos == null) assentos = "D7, D8";
        if (horario == null) horario = "14:20";

        ((TextView) findViewById(R.id.textFilmeConfirmacao)).setText(filme);
        ((TextView) findViewById(R.id.textPosterMini)).setText(
                filme.substring(0, Math.min(4, filme.length())).toUpperCase());
        ((TextView) findViewById(R.id.textHorarioConfirmacao))
                .setText(getString(R.string.session_time_label, horario));
        ((TextView) findViewById(R.id.textAssentosConfirmacao))
                .setText(getString(R.string.seats_label, assentos));

        // Código do ingresso gerado para o protótipo
        String codigo = "HTG-" + (10000 + new Random().nextInt(90000));
        ((TextView) findViewById(R.id.textCodigoIngresso)).setText(codigo);

        findViewById(R.id.btnFechar).setOnClickListener(v ->
                voltarAoInicio());
        findViewById(R.id.btnMeusIngressos).setOnClickListener(v ->
                voltarAoInicio());
    }

    private void voltarAoInicio() {
        Intent intent = new Intent(this, HomeActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        finish();
    }
}
