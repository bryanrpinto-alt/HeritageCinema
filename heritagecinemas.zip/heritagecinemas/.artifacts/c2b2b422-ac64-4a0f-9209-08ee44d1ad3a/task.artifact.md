# Lista de Tarefas - Héritage Cinemas

- `[x]` 1. Remoção da tela duplicada de localização (`MainActivity`)
  - `[x]` Consolidar `MainActivity.java` em `HomeActivity.java`
  - `[x]` Consolidar `activity_main.xml` em `activity_home.xml`
  - `[x]` Atualizar `AndroidManifest.xml`
- `[x]` 2. Implementação da Tela de Login
  - `[x]` Criar `res/layout/activity_login.xml`
  - `[x]` Criar `com/example/heritagecinemas/LoginActivity.java`
  - `[x]` Registrar `LoginActivity` como LAUNCHER no `AndroidManifest.xml`
- `[x]` 3. Implementação da Tela "Seja Bem-Vindo" / Home
  - `[x]` Atualizar `res/layout/activity_home.xml`
  - `[x]` Atualizar `com/example/heritagecinemas/HomeActivity.java`
  - `[x]` Adicionar strings em `res/values/strings.xml`
- `[x]` 4. Verificação e Compilação do Projeto
  - `[x]` Executar `gradle_build("app:assembleDebug")`
