# Plano de Implementação - Consolidação e Telas Login & Início

Atualização do plano com base na orientação do usuário:
1. **Consolidar Telas de Localização**: Remover a redundância entre `MainActivity` e `HomeActivity` (excluir `MainActivity` e `activity_main.xml`).
2. **Criar Tela de Login**: Implementar `LoginActivity` e `activity_login.xml` com o visual da imagem (Logo HÉRITAGE, inputs de E-mail/Senha, botão ENTRAR, link "Criar conta").
3. **Criar Tela "Seja Bem-Vindo" (Home)**: Implementar `HomeActivity` e `activity_home.xml` com o visual da imagem (Saudação "Olá, seja bem-vindo!", Card de GPS do cinema mais próximo, Banner EM DESTAQUE "VÉRITY" com botão "SAIBA MAIS", seção "Em cartaz" com filmes "Verity" e "A Odisseia", e barra de navegação inferior).

---

## Proposed Changes

### Módulo `:app`

#### [DELETE] [MainActivity.java](file:///Users/senai/Downloads/heritagecinemas/app/src/main/java/com/example/heritagecinemas/MainActivity.java)
#### [DELETE] [activity_main.xml](file:///Users/senai/Downloads/heritagecinemas/app/src/main/res/layout/activity_main.xml)
- Remover a tela duplicada de localização (`MainActivity.java` e `activity_main.xml`).

#### [NEW] [activity_login.xml](file:///Users/senai/Downloads/heritagecinemas/app/src/main/res/layout/activity_login.xml)
- Implementar a tela de login idêntica ao protótipo da imagem:
  - Logo "HÉRITAGE CINEMAS - O CINEMA QUE ATRAVESSA O TEMPO" em dourado `#D4AF37`.
  - Input de E-mail com ícone de carta.
  - Input de Senha com ícone de cadeado e alternador de visibilidade.
  - Botão "ENTRAR" em dourado `#D4AF37`.
  - Link "Criar conta".
  - Detalhe gráfico de película de filme dourada no rodapé.

#### [NEW] [LoginActivity.java](file:///Users/senai/Downloads/heritagecinemas/app/src/main/java/com/example/heritagecinemas/LoginActivity.java)
- Atividade de entrada com clique em "ENTRAR" direcionando para a tela de início (`HomeActivity`).

#### [MODIFY] [activity_home.xml](file:///Users/senai/Downloads/heritagecinemas/app/src/main/res/layout/activity_home.xml)
- Implementar a tela "Seja bem-vindo" idêntica ao protótipo da imagem:
  - Topo com logo HÉRITAGE, ícone de busca e ícone de localização GPS.
  - Título "Olá, seja bem-vindo!" e subtítulo "Que tal um bom filme hoje?".
  - Card estilizado "Cinema mais próximo - Shopping Aurora - 2,4 km" com seta.
  - Card "EM DESTAQUE" do filme "VÉRITY" ("ALGUMAS VERDADES NÃO DEVEM SER REVELADAS") com botão "SAIBA MAIS" e indicadores de carousel.
  - Seção "Em cartaz" com "Ver todos ->" e cards de filmes: "Verity" (Suspense • 16 anos) e "A Odisseia" (Aventura • 12 anos).
  - Barra de navegação inferior com opções: Início (ativo), Filmes, Ingressos, Perfil.

#### [MODIFY] [HomeActivity.java](file:///Users/senai/Downloads/heritagecinemas/app/src/main/java/com/example/heritagecinemas/HomeActivity.java)
- Ativar a lógica de busca GPS do cinema mais próximo, clique no filme/botão "SAIBA MAIS" abrindo os detalhes e navegação para os assentos.

#### [MODIFY] [AndroidManifest.xml](file:///Users/senai/Downloads/heritagecinemas/app/src/main/AndroidManifest.xml)
- Definir `LoginActivity` como atividade LAUNCHER inicial e remover a referência à `MainActivity`.

---

## Verification Plan

### Automated Tests
- Executar `./gradlew app:assembleDebug` para validar a compilação de todas as atividades e layouts.

### Manual Verification
- Iniciar o aplicativo na tela de `LoginActivity`.
- Clicar em "ENTRAR" para acessar a tela "Seja bem-vindo" (`HomeActivity`).
- Verificar a exibição do cinema GPS, banner em destaque "VÉRITY" e os filmes em cartaz.
